#ifndef __ASSESSMENT_H__
#define __ASSESSMENT_H__

#include <cv.h>
#include <highgui.h>

uchar blurIdentify(IplImage* input);
double calGMG(IplImage* input);
double calLuminanceSim(IplImage* input1,IplImage* input2);
double calContrastSim(IplImage* input1,IplImage* input2);
double calStructSim(IplImage* input1,IplImage* input2);

#endif